create view FILTER_CATEGORY_VIEW as
select distinct c.name
from product p
         join category c on p.category_id = c.id
order by 1
/

