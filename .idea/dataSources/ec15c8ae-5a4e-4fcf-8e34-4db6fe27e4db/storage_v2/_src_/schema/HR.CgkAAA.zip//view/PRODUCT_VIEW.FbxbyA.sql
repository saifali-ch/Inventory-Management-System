create view PRODUCT_VIEW as
select p.id id, p.name name, c.name category, description
from product p
         inner join category c on p.category_id = c.id
order by 1
/

